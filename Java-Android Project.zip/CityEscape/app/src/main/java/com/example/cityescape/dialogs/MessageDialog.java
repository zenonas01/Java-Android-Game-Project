package com.example.cityescape.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.example.cityescape.R;
import com.google.android.material.card.MaterialCardView;


public class MessageDialog extends Dialog {
    Context mCtx;
    Handler h;
    private ImageView ivLogo;
    private MaterialCardView mcvRestart;
    private TextView tvMessage, tvOK, tvRestart;


    public MessageDialog(Context context, String loadingMessage, int imageID, Boolean showRestart, ClickListener clickListener) {
        super(context, R.style.TransparentProgressDialog);
        h = new Handler();
        setTitle(null);
        setCancelable(false);
        setOnCancelListener(null);
        mCtx = context;
        setContentView(R.layout.loading_dialog);
        ivLogo = findViewById(R.id.ivLogo);
        tvMessage = findViewById(R.id.tvMessage);
        mcvRestart = findViewById(R.id.mcvRestart);
        tvRestart = findViewById(R.id.tvRestart);
        tvOK = findViewById(R.id.tvOK);
        tvMessage.setText(loadingMessage);
        if(loadingMessage == null || loadingMessage.isEmpty()){
            tvMessage.setVisibility(View.GONE);
        } else {
            tvMessage.setVisibility(View.VISIBLE);
        }
        if(imageID <= 0){
            ivLogo.setVisibility(View.GONE);
        } else {
            ivLogo.setVisibility(View.VISIBLE);
            ivLogo.setImageDrawable(ContextCompat.getDrawable(context, imageID));
        }
        if(!showRestart){
            mcvRestart.setVisibility(View.GONE);
        } else {
            mcvRestart.setVisibility(View.VISIBLE);
        }
        tvRestart.setOnClickListener(view -> {
            clickListener.onRestart();
            dismiss();
        });
        tvOK.setOnClickListener(view -> {
            clickListener.onOk();
            dismiss();
        });
    }


    @Override
    public void show() {
        try {
            super.show();
        }catch (Exception ex){

        }
    }

    public interface ClickListener{
        public void onRestart();
        public void onOk();
    }

}

