package com.example.cityescape.activites;

import static java.lang.Thread.sleep;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.cityescape.R;
import com.example.cityescape.dialogs.MessageDialog;
import com.example.cityescape.utils.Node;
import com.example.cityescape.utils.Server;
import com.google.android.material.card.MaterialCardView;

public class MainActivity extends AppCompatActivity {

    TextView tvLevel, tvQuestion, tvOptionA, tvOptionB;
    RatingBar rbLives;
    MaterialCardView mcvA, mcvB, mcvNext;
    String selectedOption = "";
    int lives = 3;
    Node n;
    Server server;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        setContentView(R.layout.activity_main);
        initControls();
        MessageDialog md = new MessageDialog(this, "WELCOME TO THE CITY ESCAPE/TREASURE HUNT GAME!\nTo navigate through the questions, you have to choose an option \nYOU HAVE 3 LIVES INDICATED BY THE HEART EMOJIS", 0, false, new MessageDialog.ClickListener() {
            @Override
            public void onRestart() {

            }

            @Override
            public void onOk() {

            }
        });
        md.show();
    }

    private void initControls() {
        tvLevel = findViewById(R.id.tvLevel);
        tvQuestion = findViewById(R.id.tvQuestion);
        tvOptionA = findViewById(R.id.tvOptionA);
        tvOptionB = findViewById(R.id.tvOptionB);
        rbLives = findViewById(R.id.rbLives);
        rbLives.setNumStars(lives);
        mcvA = findViewById(R.id.mcvA);
        mcvB = findViewById(R.id.mcvB);
        mcvNext = findViewById(R.id.mcvNext);
        try {
            server = new Server(this);
            attachListens();
            n = Server.getNode(1);
            showQuestion();
        } catch (Exception ex){
            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void showQuestion() {
        resetView();
        rbLives.setRating(lives+0f);
        assert n != null; // Claims that n is not null.
        tvLevel.setText(String.valueOf(n.getLEVEL()));
        tvQuestion.setText(n.getText() + n.getQuestion());
        tvOptionA.setText("Option A: " + n.getA_ID_Text());
        tvOptionB.setText("Option B: " + n.getB_ID_Text());
    }

    private void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private void attachListens() {
        mcvA.setOnClickListener(view -> {
            selectedOption = "A";
            setOptionSelection();
        });
        mcvB.setOnClickListener(view -> {
            selectedOption = "B";
            setOptionSelection();
        });
        mcvNext.setOnClickListener(view -> {
            if(selectedOption.isEmpty()){
                showToast("Select an option first.");
                return;
            }
            String NextID = selectedOption;

            boolean x = (!NextID.equals("A")) || (!NextID.equals("a")) || (!NextID.equals("B")) || (!NextID.equals("b"));
            x = true;

            if(NextID.equals("A")){
                NextID = String.valueOf(n.getOption_A());
            } else if(NextID.equals("a")){
                NextID = String.valueOf(n.getOption_A());
            } else if(NextID.equals("B")){
                NextID = String.valueOf(n.getOption_B());
            } else if(NextID.equals("b")){
                NextID = String.valueOf(n.getOption_B());
            }

            // Starting from the beginning if the user dies.
            // Decreasing lives by 1
            // Sorting levels.
            if(String.valueOf(n.getOption_A()).equals(String.valueOf(-1)) && (String.valueOf(n.getLEVEL()).equals(String.valueOf(1))) && (lives>0)){
                showToast("You DIED!");
                lives = lives - 1;
                n = Server.getNode(Integer.parseInt("1"));
                if(lives > 0){
                    showQuestion();
                }
            } else if(String.valueOf(n.getOption_B()).equals(String.valueOf(-1)) && (String.valueOf(n.getLEVEL()).equals(String.valueOf(1))) && (lives>0)) {
                showToast("You DIED!");
                lives = lives -1;
                n = Server.getNode(Integer.parseInt("1"));
                if(lives > 0){
                    showQuestion();
                }
            } else if(String.valueOf(n.getOption_A()).equals(String.valueOf(-1)) && (String.valueOf(n.getLEVEL()).equals(String.valueOf(2))) && (lives>0)){
                showToast("You DIED!");
                lives = lives - 1;
                n = Server.getNode(Integer.parseInt("50"));
                if(lives > 0){
                    showQuestion();
                }
            } else if(String.valueOf(n.getOption_B()).equals(String.valueOf(-1)) && (String.valueOf(n.getLEVEL()).equals(String.valueOf(2))) && (lives>0)) {
                showToast("You DIED!");
                lives = lives - 1;
                n = Server.getNode(Integer.parseInt("50"));
                if(lives > 0){
                    showQuestion();
                }
            }
            // Winning message in case the user wins.
            else if(String.valueOf(n.getOption_A()).equals(String.valueOf(-2)) && (lives>0)){
                MessageDialog md = new MessageDialog(this, "C O N G R A D U L A T I O N S!" + "\n" + "You finished the game!", R.drawable.congrats, true, new MessageDialog.ClickListener() {
                    @Override
                    public void onRestart() {
                        restart();
                    }

                    @Override
                    public void onOk() {
                        finishAffinity();
                    }
                });
                md.show();
                rbLives.setRating(lives+0f);
            } else if(String.valueOf(n.getOption_B()).equals(String.valueOf(-2)) && (lives>0)) {
                MessageDialog md = new MessageDialog(this, "C O N G R A D U L A T I O N S!" + "\n" + "You finished the game!", R.drawable.congrats, true, new MessageDialog.ClickListener() {
                    @Override
                    public void onRestart() {
                        restart();
                    }

                    @Override
                    public void onOk() {
                        finishAffinity();
                    }
                });
                md.show();
                rbLives.setRating(lives+0f);
            }

            // If the user never choose a fatal option the game keeps rolling until the end.
            else{
                n = Server.getNode(Integer.parseInt(NextID));
                if(lives > 0){
                    showQuestion();
                }
            }
            // Checking if the user has no lives left, in order to terminate the game.
            if(lives==0){
                MessageDialog md = new MessageDialog(this, "G A M E   O V E R..." + "\n" + "You have: " + lives +" <3 left.", R.drawable.failed, true, new MessageDialog.ClickListener() {
                    @Override
                    public void onRestart() {
                        restart();
                    }

                    @Override
                    public void onOk() {
                        finishAffinity();
                    }
                });
                md.show();
                rbLives.setRating(lives+0f);
            }
        });
    }

    private void restart() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    private void setOptionSelection() {
        if(selectedOption.equals("A")){
            mcvA.setCardBackgroundColor(ContextCompat.getColor(this, R.color.selected_option_color));;
            tvOptionA.setTextColor(ContextCompat.getColor(this, R.color.white));
            mcvB.setCardBackgroundColor(ContextCompat.getColor(this, R.color.white));;
            tvOptionB.setTextColor(ContextCompat.getColor(this, R.color.black));
        } else if(selectedOption.equals("B")){
            mcvA.setCardBackgroundColor(ContextCompat.getColor(this, R.color.white));;
            tvOptionA.setTextColor(ContextCompat.getColor(this, R.color.black));
            mcvB.setCardBackgroundColor(ContextCompat.getColor(this, R.color.selected_option_color));;
            tvOptionB.setTextColor(ContextCompat.getColor(this, R.color.white));
        }
    }

    private void resetView() {
        mcvA.setCardBackgroundColor(ContextCompat.getColor(this, R.color.white));;
        tvOptionA.setTextColor(ContextCompat.getColor(this, R.color.black));
        mcvB.setCardBackgroundColor(ContextCompat.getColor(this, R.color.white));;
        tvOptionB.setTextColor(ContextCompat.getColor(this, R.color.black));
        selectedOption = "";
    }
}