package com.example.cityescape.utils;

public class Node {

    //
    private int LEVEL;
    private int ID;
    private int Option_A;
    private int Option_B;

    private String A_ID_Text;
    private String B_ID_Text;
    private String Text;
    private String Question;

    //
    @Override
    public String toString() {
        return "Node:" +
                LEVEL + "," +
                ID + "," +
                Option_A + "," +
                Option_B + "," +
                A_ID_Text + "," +
                B_ID_Text + "," +
                Text + "," +
                Question;
    }


    //
    public Node() {
    }


    //
    public Node(int level, int id, int option_A, int option_B, String a_ID_Text, String b_ID_Text, String text, String question) {

        this.LEVEL= level;
        ID = id;
        Option_A = option_A;
        Option_B = option_B;
        A_ID_Text = a_ID_Text;
        B_ID_Text = b_ID_Text;
        Text = text;
        Question = question;
    }


    //
    public int getLEVEL() {
        return LEVEL;
    }

    public void setLEVEL(int LEVEL) {
        this.LEVEL = ID;
    }
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getOption_A() {return Option_A;}

    public void setOption_A(int a_ID) {Option_A = a_ID;}

    public int getOption_B() {
        return Option_B;
    }

    public void setOption_B(int b_ID) {
        Option_B = b_ID;
    }

    public String getA_ID_Text() {
        return A_ID_Text;
    }

    public void setA_ID_Text(String a_ID_Text) {
        A_ID_Text = a_ID_Text;
    }

    public String getB_ID_Text() {
        return B_ID_Text;
    }

    public void setB_ID_Text(String b_ID_Text) {
        B_ID_Text = b_ID_Text;
    }

    public String getText() {
        return Text;
    }

    public void setText(String text) {
        Text = text;
    }

    public String getQuestion() {
        return Question;
    }

    public void setQuestion(String question) {
        Question = question;
    }


}
