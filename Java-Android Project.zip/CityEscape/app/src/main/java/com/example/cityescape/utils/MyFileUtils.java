package com.example.cityescape.utils;

import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MyFileUtils {

    public static String dataFileName = "data.csv";

    public static String loadDataFile(Context context) {
        String tContents = "";

        try {
            InputStream stream = context.getAssets().open(dataFileName);

            int size = stream.available();
            byte[] buffer = new byte[size];
            stream.read(buffer);
            stream.close();
            tContents = new String(buffer);
        } catch (Exception e) {
            // Handle exceptions here
        }

        return tContents;

    }

    public static File getDataFile(Context context){
        File f = new File(context.getCacheDir() + "/" + dataFileName);
        if (!f.exists()) {
            try {

                InputStream is = context.getAssets().open(dataFileName);
                byte[] buffer = new byte[1024];
                is.read(buffer);
                is.close();


                FileOutputStream fos = new FileOutputStream(f);
                fos.write(buffer);
                fos.close();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return f;
    }
}
