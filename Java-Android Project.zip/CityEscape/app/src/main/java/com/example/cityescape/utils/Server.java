package com.example.cityescape.utils;

import android.content.Context;

import java.io.FileNotFoundException;
import java.util.ArrayList;


public class Server {

    private static ArrayList<Node> nodes;
    Context context;

    public Server(Context context) throws FileNotFoundException {
        this.context = context;
        String text = MyFileUtils.loadDataFile(context);
        String[] lines = text.split("\n");
        nodes = new ArrayList<Node>();
        for(String line: lines){

//            String line = getLine();

            //Splitting the array on commas.
            String[] lineArray = line.replace(",",",").split(",");

            //Convert Integers to Strings, and then allocating each column of the CSV file to the correct index of the array.

            int LEVEL = Integer.parseInt(lineArray[0]);
            int ID = Integer.parseInt(lineArray[1]);
            int Option_A = Integer.parseInt(lineArray[2]);
            int Option_B = Integer.parseInt(lineArray[3]);

            String A_ID_Text = lineArray[4];
            String B_ID_Text = lineArray[5];
            String Text = lineArray[6];
            String Question = lineArray[7];

            //Creating the Node Class.
            Node n = new Node(LEVEL,ID,Option_A,Option_B,A_ID_Text,B_ID_Text,Text,Question);

            //Adding Node to ArrayList.
            nodes.add(n);


        }

    }

    public String toString() {
        String string = "";
        //looping mechanisms to build our string
        for (Node node : nodes)
            {string += node.toString() + "\n";}
        return string;
    }


    //

    public static Node getNode(int NodeID) {
        for(Node n: nodes){
            if(n.getID() == NodeID){
                return n;
            }
        }
        return null;

    }


}
